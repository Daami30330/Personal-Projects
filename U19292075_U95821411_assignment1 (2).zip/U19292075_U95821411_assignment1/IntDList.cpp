#include "IntDList.hpp"
#include "IntDList_node.hpp"
#include <sstream>
#include <string>
#include <iomanip>
#include <iostream>

IntDLList::IntDLList() {
    
    // creating a new node, head of the list
    // set next pointer of head to point to itself
    // set prev pointer of head to point itself
    // both indicate an empty list
    
    ListHead = new IntDLLNode();
    ListHead->next = ListHead;
    ListHead->prev = ListHead;
}

IntDLList::~IntDLList() {
    
    // Destructor logic to free allocated memory, if needed
}

void IntDLList::addToHead(int el) {
    
    // create new node with given element
    // point to current head->next and current head
    // update prev pointer of node thats afer current head
    // update next node of current head to new node
    
    IntDLLNode* newNode = new IntDLLNode(el, ListHead->next, ListHead);
    ListHead->next->prev = newNode;
    ListHead->next = newNode;
}

void IntDLList::insertInOrder(int el) {
    
    // Insert a new node with given value in ascending order
    
    IntDLLNode* newNode = new IntDLLNode(el);

    // Search for desired position to insert new node
    
    IntDLLNode* current = ListHead->next;
    while (current != ListHead && current->info < el) {
        current = current->next;
    }

    /** Steps to insert new node before current node **/
    
    // Set next pointer of new node to current node
    // Set prev of new node to prev node (points to node before current node)
    // Updates next pointer of node before current to point to new node. Basically inserts new node onto list after node before the current one
    // Updates prev pointer of current node to point to the new node
    
    newNode->next = current;
    newNode->prev = current->prev;
    current->prev->next = newNode;
    current->prev = newNode;
}

void IntDLList::addToTail(int el) {
    
    /** Steps to add a new node with give element  to tail end of doubly inked list  **/
    
    // create new node with given element
    // setting its next pointer to list head
    // and prev to its current tail node
    // update next pointer off current tail to point at new node
    // update prev pointer of listHead to point at new tail node
    // insertion is complete
    
    IntDLLNode* newNode = new IntDLLNode(el, ListHead, ListHead->prev);
    ListHead->prev->next = newNode;
    ListHead->prev = newNode;
}

int IntDLList::deleteFromHead() {
    
    // Handles the case if list is empty
    // return -1 indicates its empty, signals an failure
    
    if (isEmpty()) {
        return -1;
    }

    /** Steps to delete from head **/
    
    // Delete the head node and return its info
    // Store the data of node being deleted
    // Update pointers to 'BYPASS' the one being deleted
    // Delete node, frees up memory
    // then return data of deleted node
    
    IntDLLNode* deletedNode = ListHead->next;
    int deletedInfo = deletedNode->info;
    ListHead->next = deletedNode->next;
    deletedNode->next->prev = ListHead;
    delete deletedNode;
    return deletedInfo;
}

int IntDLList::deleteFromTail() {
    
    // Handles the case if list is empty
    // return -1 indicates its empty, signals an failure
    
    if (isEmpty()) {
        return -1;
    }
    
    /** Steps to delete from tail **/
    
    // Same steps as above but dealing with 'prev' not next
    // as we are deleting from the tail
    
    IntDLLNode* deletedNode = ListHead->prev;
    int deletedInfo = deletedNode->info;
    ListHead->prev = deletedNode->prev;
    deletedNode->prev->next = ListHead;
    delete deletedNode;
    return deletedInfo;
}

void IntDLList::deleteNode(int el) {
    
    /** Steps to delete the first occurrence of a node with the given value **/
    
    // Set current to first node after the list head
    // loop through list until current reaches listHead
    // Check if current info is equal to target element
    // then update pointers of nodes to skip to current
    // Delete current node, freeing memory
    // exit after succcesfully removing node
    
    IntDLLNode* current = ListHead->next;
    while (current != ListHead) {
        if (current->info == el) {
            current->prev->next = current->next;
            current->next->prev = current->prev;
            delete current;
            return;
        }
        
        // move to next node in list, update iterator
        current = current->next;
    }
}

bool IntDLList::isInList(int el) const {
    
    /** Steps checking if the given value is present in the list **/
    
    // Set current to first node after list head
    // loop through till current reaches listHead
    // if current info is equal to target element
    // return true (is in list)
    // Update iterator
    // if not in list, return false
    
    IntDLLNode* current = ListHead->next;
    while (current != ListHead) {
        if (current->info == el) {
            return true;
        }
        current = current->next;
    }
    return false;
}

string IntDLList::addToString() const {
    
    /** steps the elements of the list to a string for printing **/
    
    // Initialize empty string to store result
    // declare pointer 'current' to first node after list head
    // loop through till current reaches ListHead
    // append string representation of curr node info to result
    //move current to node in list
    // return concatenated string
    
    string result;
    IntDLLNode* current = ListHead->next;
    while (current != ListHead) {
        result += to_string(current->info);
        current = current->next;
    }
    return result;
}
