#ifndef INTDLISTNODE_H
#define INTDLISTNODE_H

class IntDLLNode {
public:
    int info;
    IntDLLNode* next;
    IntDLLNode* prev;

    // Default constructor
    IntDLLNode() : info(0), next(nullptr), prev(nullptr) {}

    // Parameterized constructor
    IntDLLNode(int el, IntDLLNode* ptr1 = nullptr, IntDLLNode* ptr2 = nullptr) {
        info = el;
        next = ptr1;
        prev = ptr2;
    }
};

#endif /* INTDLISTNODE_H */
