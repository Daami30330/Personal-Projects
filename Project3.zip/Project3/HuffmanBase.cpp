#include "HuffmanBase.hpp"
#include <iostream>
#include <stack>
#include "HeapQueue.hpp"

/*
 Project 3:
 
 Imaad Fahimuddin #U95821411
 Brandt Ousley #U19292075
 
 */

// this returns the char stored in this node
char HuffmanNode::getCharacter() const {
    return character;
}

// returns the frequency of how many times the char is stored in the node
size_t HuffmanNode::getFrequency() const {
    return frequency;
}

// checking if it is a leaf node
bool HuffmanNode::isLeaf() const {
    return (left == nullptr && right == nullptr);
}

// checking if the node is branch node
bool HuffmanNode::isBranch() const {
    return (left != nullptr || right != nullptr);
}

// checking if this node is root of the tree
bool HuffmanNode::isRoot() const {
    return (parent == nullptr);
}

// this is being used. operator comparision, for comparing two huffman nodes based on freq and char
bool HuffmanNode::Compare::operator()(const HuffmanNode &n1, const HuffmanNode &n2) const {
    if (n1.frequency == n2.frequency) {
        if (lessThan)
            return n1.character < n2.character;
        else
            return n1.character >= n2.character;
    } else {
        if (lessThan)
            return n1.frequency < n2.frequency;
        else
            return n1.frequency >= n2.frequency;
    }
}

// comparison op. that copmares the two huffman node ptrs
bool HuffmanNode::Compare::operator()(const HuffmanNode *node1, const HuffmanNode *node2) const {
    return operator()(*node1, *node2);
}

// Compressing using Huffman Technique
std::string HuffmanTreeBase::compress(const std::string inputStr) {
    int charFrequencyMap[256] = {0}; // initialize array to store frequency of each char in test strings input

    // calculating the frewuency of each char
    for (int i = 0; i < inputStr.length(); i++) {
        charFrequencyMap[inputStr[i]]++;
    }
    // creating a priority queue to store huffman nodes based on the frequency
    HeapQueue<HuffmanNode*, HuffmanNode::Compare> priorityQueue;
    // initiating a priority queue with leaf nodes that represent the char with their frequencies
    for (int i = 0; i < 256; i++) {
        if (charFrequencyMap[i] != 0) {
            HuffmanNode* node = new HuffmanNode((char)i, charFrequencyMap[i]);
            priorityQueue.insert(node);
        }
    }
    
    // building the huffman tree by combining two nodes with lowest frequency, repeatedly using do while

    do {
        //extracting two nodes with lowest freq. from priority q.
        HuffmanNode* minNode1 = priorityQueue.min();
        priorityQueue.removeMin();
        HuffmanNode* minNode2 = priorityQueue.min();
        priorityQueue.removeMin();
        // creating a parent node with a freq equal to the sum of freq.
        int totalFrequency = (minNode1->getFrequency() + minNode2->getFrequency());
        HuffmanNode* parentNode = new HuffmanNode('\0', totalFrequency, nullptr, minNode1, minNode2);
        // set the parent node as the parent of its children
        minNode1->parent = parentNode;
        minNode2->parent = parentNode;
        // insert the parent node back into priority q.
        priorityQueue.insert(parentNode);
    } while (priorityQueue.size() != 1);
    // setting root ptr to the single node remaining in the priority q, which is the root of the huffman tree
    rootPtr = priorityQueue.min();

    // using an arrat to store the huffman codes for each single char
    std::string codeMap[256];
    std::string code = "";
    std::string output = "";
    
    // generate the codes for each char in string
    for (int i = 0; i < 256; i++) {
        if (charFrequencyMap[i] != 0) {
            generateHuffmanCodes(priorityQueue.min(), codeMap, code);
        }
    }
    
    // encoding input string using the generated huffman codes
    for (int i = 0; i < inputStr.length(); i++) {
        output += codeMap[inputStr[i]];
    }
    // finally, returning the compressed output string.
    return output;
}

// use of this function is to serialize the huffman tree into a string rep.
std::string HuffmanTreeBase::serializeTree() const {
    // if the root ptr is null it returns an empty string ""
    if (rootPtr == nullptr) {
        return "";
    }
    // initializing an empty string to store serialize tree
    std::string serialized = "";
    // using our helper function to recursively iteratre the sreialize huffman tree
    serializeHuffman(rootPtr, serialized);
    return serialized; // returning the serialized string rep. of the huffman tree
}


// this functin genrerates huffman codes for eachchar in the tree
void HuffmanTreeBase::generateHuffmanCodes(const HuffmanNode* currentNode, std::string* codes, std::string code) {
    if (currentNode == nullptr)
        return; // if null return

        // if the current node is a leaf, assign the huffman code to the corresponding char
    if (currentNode->isLeaf())
        codes[currentNode->getCharacter()] = code;

    // reecursively iterate the left and right subtrees, '0' for left and '1' for right
    generateHuffmanCodes(currentNode->left, codes, code + "0");
    generateHuffmanCodes(currentNode->right, codes, code + "1");
}

void HuffmanTreeBase::serializeHuffman(const HuffmanNode* currentNode, std::string& serialized) const {
    if (currentNode == nullptr)
        return; // return if null

    // serialisze left tree
    serializeHuffman(currentNode->left, serialized);
    // now the right tree
    serializeHuffman(currentNode->right, serialized);

    // if node is a leaf node, append 'L' followed by the char to its serialized string
    if (currentNode->isLeaf())
        serialized = serialized + "L" + currentNode->getCharacter();
    //if it is a branch node, append 'B'
    if (currentNode->isBranch())
        serialized += "B";
}

// Deserializes the Huffman tree from a serialized string representation
void processSerializedData(const std::string& serialized, int length, int i, std::stack<HuffmanNode*>& nodeStack) {
    if (i >= length) {
        return; // if i greather then lenght of serialized string then return
    }

    // getting current char from the serialized string
    char currentChar = serialized[i];
    // if 'L', indicates a leaf node
    if (currentChar == 'L') {
        // processing for the next char
        processSerializedData(serialized, length, i + 1, nodeStack);
    } else if (currentChar != 'B') {
        // if is not 'L' or 'B', create a leaf node
        HuffmanNode* huffmanNode = new HuffmanNode(currentChar, 0);
        // pushing node onto stack
        nodeStack.push(huffmanNode);
        processSerializedData(serialized, length, i + 1, nodeStack);
    } else if (currentChar == 'B') {
        // check if stack has at least two nodes to pop
        if (nodeStack.size() < 2) {
            // error handling
            return;
        }
        
        // pop both nodes from stack, right child then left child
        HuffmanNode* rightChild = nodeStack.top();
        nodeStack.pop();
        HuffmanNode* leftChild = nodeStack.top();
        nodeStack.pop();
        // creating a branch node with '\0' char and freq. of 0 linking to left and right children
        HuffmanNode* branchNode = new HuffmanNode('\0', 0, nullptr, leftChild, rightChild);
        // pushing it onto the stack
        nodeStack.push(branchNode);
        // set the parent of the left and right children as branch node
        rightChild->parent = branchNode;
        leftChild->parent = branchNode;
        // processing the serialized data for the next char
        processSerializedData(serialized, length, i + 1, nodeStack);
    }
}


// decompress a string using huffamn enocde
std::string HuffmanTreeBase::decompress(const std::string compressedCode, const std::string serialized) {
    std::string decompressed = ""; // initalized empty string
    // getting length
    int length = serialized.length();
    std::stack<HuffmanNode*> nodeStack;
    // process the serialized data to represent the HT
    processSerializedData(serialized, length, 0, nodeStack);
    // getting the root node of tree
    HuffmanNode* rootNode = nodeStack.top();
    // now removing it from the stack
    nodeStack.pop();
    // traversing beginning at the root node
    HuffmanNode* current = rootNode;
    // iterating the compressesion
    for (int i = 0; i < compressedCode.length(); i++) {
        char currentChar = compressedCode[i];
        // if current is 0, move to left child
        if (currentChar == '0')
            current = current->left;
        else
            // if 1, move to the right child
            current = current->right;

        // if current is a leaf node then we append its char to the decompression string
        if (current->isLeaf()) {
            decompressed += current->getCharacter();
            // resetting current node to the root for next char
            current = rootNode;
        }
    }
    // return decompressed string
    return decompressed;
}

