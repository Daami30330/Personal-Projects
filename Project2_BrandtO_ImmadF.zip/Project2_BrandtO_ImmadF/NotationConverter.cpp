#include "NotationConverter.hpp"
#include <deque>
#include <sstream>
#include <iostream>


/* 
 
 Project 2
 
 Group members and USF ID:
 
 Immad Fahimuddin U95821411
 Brandt Ousley U19292075
 
 */


class NotationConverter : public NotationConverterInterface {
public:
    // Convert postfix expression to infix expression
    std::string postfixToInfix(std::string inStr) override {
        std::deque<std::string> operands;
        std::istringstream iss(inStr);
        std::string token;

        while (iss >> token) {
            // Check if the token is a letter or number
            if (isOperand(token)) {
                operands.push_back(token);
            } else {
                // If it's a letter or number, pop two operands from deque, construct infix expression and push back
                std::string operand2 = operands.back();
                operands.pop_back();
                std::string operand1 = operands.back();
                operands.pop_back();
                // concatenate result
                std::string result = "(" + operand1 + " " + token + " " + operand2 + ")";
                operands.push_back(result);
            }
        }

        return operands.back(); // return final infix operation
    }
    // Convert postfix expression to prefix expression
    std::string postfixToPrefix(std::string inStr) override {
        std::deque<std::string> operands;
        std::istringstream iss(inStr);
        std::string token;

        while (iss >> token) {
            // Check if the token is a letter or number
            if (isOperand(token)) {
                operands.push_back(token);
            } else {
                // If it's an operator, pop two operands from deque, construct prefix expression and push back
                std::string operand2 = operands.back();
                operands.pop_back();
                std::string operand1 = operands.back();
                operands.pop_back();

                std::string result = token + " " + operand1 + " " + operand2;
                operands.push_back(result);
            }
        }

        return operands.back(); // return final prefix expression
    }
    // Convert infix expression to postfix expression
    std::string infixToPostfix(std::string inStr) override {
        std::istringstream iss(inStr);
        std::ostringstream oss;
        std::deque<char> operators;
        char token;

        while (iss >> token) {
            if (isOperand(std::string(1, token))) {
                oss << token << " ";
            } else if (token == '(') {
                operators.push_back(token);
            } else if (token == ')') {
                while (!operators.empty() && operators.back() != '(') { // discard the '('
                    oss << operators.back() << " ";
                    operators.pop_back();
                }
                if (!operators.empty()) operators.pop_back();
            } else { // it is an operator
                while (!operators.empty() && precedence(operators.back()) >= precedence(token)) {
                    oss << operators.back() << " ";
                    operators.pop_back();
                }
                operators.push_back(token); // return final postfix expression
            }
        }

        while (!operators.empty()) {
            oss << operators.back() << " ";
            operators.pop_back();
        }

        return oss.str();
    }
        // convert infix to prefix
        std::string infixToPrefix(std::string inStr) override {
        std::istringstream iss(inStr);
        std::ostringstream oss;
        std::deque<std::string> operands;
        std::deque<char> operators;
        char token;

        while (iss >> token) {
            // check if operand
            if (isOperand(std::string(1, token))) {
                // if so, push it to front of deque
                operands.push_front(std::string(1, token));
                // if an opening parenthesis, push it to front of deque
            } else if (token == '(') {
                // if a closed one
                operators.push_front(token);
            } else if (token == ')') {
                while (!operators.empty() && operators.front() != '(') {
                    // process operators til an opening parenthesis is found
                    processTop(operands, operators);
                }
                // if not empty, pop front, opening ( )
                if (!operators.empty()) {
                    operators.pop_front();
                }
            } else {
                // else will call proccess top and execute, if an operator
                while (!operators.empty() && precedence(operators.front()) >= precedence(token)) {
                    // using func to process higher/equal precedence
                    processTop(operands, operators);
                }
                operators.push_front(token); // push front
            }
        }
            // process any left operators in deque
        while (!operators.empty()) {
            processTop(operands, operators);
        }

        return operands.front(); // return final expression (the front element of deque)
    }
    // convert prefox to infix
    std::string prefixToInfix(std::string inStr) override {
        reverseString(inStr);
        std::istringstream iss(inStr);
        std::deque<std::string> operands;
        std::string token;

        while (iss >> token) {
            // check if operand (letter/number)
            if (isOperand(token)) {
                operands.push_back(token);
            } else {
                // if it is one, pop two opperands from deque, construct infix and push back
                std::string operand2 = operands.back();
                operands.pop_back();
                std::string operand1 = operands.back();
                operands.pop_back();

                std::string result = "(" + operand2 + " " + token + " " + operand1 + ")";
                operands.push_back(result);
            }
        }

        return operands.back(); // return final infix expression
    }
    
    // convert prefix to postfix
    std::string prefixToPostfix(std::string inStr) override {
        reverseString(inStr); // reverse it
        std::istringstream iss(inStr);
        std::deque<std::string> operands;
        std::string token;

        while (iss >> token) {
            // same as previous statements
            if (isOperand(token)) {
                operands.push_back(token);
            } else {
                // same operation as previous, if is, pop two and construct postfix expression
                std::string operand2 = operands.back();
                operands.pop_back();
                std::string operand1 = operands.back();
                operands.pop_back();

                std::string result = operand2 + " " + operand1 + " " + token + " ";
                operands.push_back(result);
            }
        }

        return operands.back(); // return final expression
    }


private:
    // checking if character is an operator
    bool isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }
    // checking if a token is an operand
    bool isOperand(const std::string& token) {
        return std::all_of(token.begin(), token.end(), [](char c) {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
        });
    }
    // used to determine the precedence of an operator
    // higher the value ( int value it returns), higher the precedence
    int precedence(char op) {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/') return 2;
        return 0;
    }
    // reverse string, similar operation/logic from exam
    void reverseString(std::string& str) {
        int start = 0;
        int end = str.length() - 1;

        while (start < end) {
            std::swap(str[start], str[end]);
            ++start;
            --end;
        }
    }
    // func to process top elements of operand/deque
    void processTop(std::deque<std::string>& operands, std::deque<char>& operators) {
        // retrieve second operand from front of deque
        std::string operand2 = operands.front();
        operands.pop_front();
        // same as 2nd, but for first opperand
        std::string operand1 = operands.front();
        operands.pop_front();
        // construct a result strong, concatenate first and second operand
        std::string result = std::string(1, operators.front()) + " " + operand1 + " " + operand2;
        // push result string to the front of deque
        operands.push_front(result);
        // pop (remove) 'processed' operator from front of deque
        operators.pop_front();
    }
};
